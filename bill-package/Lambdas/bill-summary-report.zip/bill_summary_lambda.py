import boto3
import os
import logging
import json
import operator
import datetime
from datetime import date, timedelta, datetime

# Initialize logging
logger = logging.getLogger()
loglevel = os.environ.get('loglevel', 'INFO')
logger.setLevel(loglevel)

# Create the clients outside of the handler.
ce = boto3.client('ce')
sns = boto3.client('sns')
org = boto3.client('organizations')
ssm = boto3.client('ssm')
ses = boto3.client('ses')

# Setting environmental variables
SSM_PARAM_PREFIX = os.environ.get('ssm_param_prefix')

def lambda_handler(event, context):
    try:
        #set log output to terminal when in debug mode
        if __debug__:
            print ('Debug ON')
            ch = logging.StreamHandler()
            logger.addHandler(ch)
        
        logger.info(f"event: {event}")
        
        # Calculating the start date and end date of previous month.
        last_day_of_prev_month = date.today().replace(day=1) - timedelta(days=1)
        start_day_of_prev_month = date.today().replace(day=1) - timedelta(days=last_day_of_prev_month.day)
        
        month_start_date = start_day_of_prev_month.strftime('%Y-%m-%d')
        month_end_date = last_day_of_prev_month.strftime('%Y-%m-%d')
        
        # Adding a day to month end date since the end date in time period of get_cost_and_usage is exclusive
        bill_end = last_day_of_prev_month + timedelta(days=1)
        bill_end_date = bill_end.strftime('%Y-%m-%d')
        
        # Initialize bill_summary_account, bill_summary_service and organization_Accounts
        bill_summary_by_account = {}
        bill_summary_by_service = {}
        organization_accounts = {}
        
        # Getting the list of all accounts in the organization and adding it to organization_accounts
        response = org.list_accounts(MaxResults = 10 )
        Accounts = response['Accounts']
        next_token = response.get('NextToken', None)
        while next_token is not None:
            response = org.list_accounts(MaxResults = 1, NextToken=next_token)
            for acc in response['Accounts']:
                Accounts.append(acc)
            next_token = response.get('NextToken', None)

        organization_accounts = Accounts
        
        # Getting Master account email id of the organization to be used as source email id for SES
        master_description = org.describe_organization()
        master_email_id = master_description['Organization']['MasterAccountEmail']
        
        # Selecting only the Account Id's from the organization_accounts
        account_ids = []
        account_names = []
        for oa in organization_accounts:
            account_ids.append(oa['Id'])
            account_names.append(oa['Name'])
        
        # Looping through each account to get the Total Bill Amount and Bill Amount by each service
        for ai, acn in zip(range(len(account_ids)), range(len(account_names))):
            param_name = SSM_PARAM_PREFIX+account_ids[ai]
            try:
                # Getting info about a parameter from the parameter store
                ssm_get_parameter_response = ssm.get_parameter(
                    Name=param_name
                )
                
                # Checking if the parameter is empty from the parameter store
                if not ssm_get_parameter_response:
                    logger.warn(f"No parameter found for account" + account_ids[ai])
                    continue

                # Getting the email id list from the parameter store
                SEPARATER = ","
                param_value = ssm_get_parameter_response["Parameter"]["Value"]
                email_list = param_value.split(SEPARATER)
                
                # If the parameter does not contain an email address, skip the account
                if not any("@" in email for email in email_list):
                    logger.warn(f"No email found, Skip account " + account_ids[ai])
                    continue
                
                # Calculating the total bill amount for each account for the previous month   
                response = ce.get_cost_and_usage(
                    TimePeriod={
                        'Start': month_start_date,
                        'End': bill_end_date
                    },
                    Granularity='MONTHLY',
                    Filter={
                        'Dimensions': {
                            'Key': 'LINKED_ACCOUNT',
                            'Values': [
                                account_ids[ai],
                            ]
                        },
                    },
                    Metrics=[
                        'UnblendedCost',
                        'UsageQuantity'
                    ],
                )
            
                bill_summary_by_account = response
                total_cost_summary = {}
                total_cost_summary = bill_summary_by_account['ResultsByTime'][0]['Total']['UnblendedCost']
                
                # Calculating the bill amount by each service for the previous month   
                response = ce.get_cost_and_usage(
                    TimePeriod={
                        'Start': month_start_date,
                        'End': bill_end_date
                    },
                    Granularity='MONTHLY',
                    Filter={
                        'Dimensions': {
                            'Key': 'LINKED_ACCOUNT',
                            'Values': [
                                account_ids[ai],
                            ]
                        },
                    },
                    Metrics=[
                        'UnblendedCost',
                        'UsageQuantity'
                    ],
                    GroupBy=[
                        {
                            'Type': 'DIMENSION',
                            'Key': 'SERVICE'
                        },
                    ]
                )
                
                bill_summary_by_service = response
                bill_summary_service = bill_summary_by_service['ResultsByTime'][0]['Groups']
                
                # Writing bill info data in html format.
                space_break = "<p style='font-size:11pt;font-family:Calibri,sans-serif;margin:0;'>&nbsp;</p>"
                billing_header = "<p style='font-size:11pt;font-family:Calibri,sans-serif;margin:0;'><span style='font-size:20pt;'>AWS Billing:</span></p>"
                liner = "<div align='center' style='font-size:11pt;font-family:Calibri,sans-serif;text-align:center;margin:0;'><b><hr align='center' width='99%' size='1'></b></div>"
                bill_date = "<p style='font-size:13pt;font-family:Calibri,sans-serif;margin:0;'><b>Billing Date</b>: " + month_start_date + " to " + month_end_date + "</p>"
                account_no = "<p style='font-size:13pt;font-family:Calibri,sans-serif;margin:0;'><b>Account No</b>: "+ json.dumps(account_ids[ai]).replace('\"','') +"</p>"
                account_name = "<p style='font-size:13pt;font-family:Calibri,sans-serif;margin:0;'><b>Account Name</b>: "+ json.dumps(account_names[acn]).replace('\"','') +"</p>"
                total_due = "<p style='font-size:11pt;font-family:Calibri,sans-serif;margin:0;'><span style='font-size:20pt;'>Total Due: " + '${:,.2f}'.format(float(total_cost_summary["Amount"])) + "</span></p>"
                service_details = "<table width='640px'>" 
                details_header = "<p style='font-size:11pt;font-family:Calibri,sans-serif;margin:0;'><span style='font-size:20pt;'>Details:</span></p>"

                # Displaying the aws service amount only if it is greater than $0
                if (float(total_cost_summary["Amount"]) < 0.001):
                    service_details = "<p style='font-size:11pt;font-family:Calibri,sans-serif;margin:0;'><span style='font-size:12pt;'>No usage for this account</span></p>"
                else:
                    for service in bill_summary_service:
                        amount =  float(service["Metrics"]["UnblendedCost"]["Amount"])
                        if (amount*100 >= 0.5):
                            service_details = service_details + "<tr> <td>" + service['Keys'][0] + ': '  + "</td> <td>" + '${:,.2f}'.format(float(amount)) + '</td></tr>'
                        
                service_details += "</table>"
                
                # Concatenate bill date, account no, total bill amount and bill amount for each service to form a bill summary for the previous month
                bill_summary = billing_header + liner + space_break + bill_date + space_break + account_no + space_break + account_name + space_break + total_due + liner + details_header + space_break + service_details + space_break + liner
                
                # Sending the bill summary to email id list 
                for e in range(len(email_list)):
                    response = ses.send_email(
                        Source=master_email_id,
                        Destination={
                            'ToAddresses': [
                                email_list[e],
                            ]
                        },
                        Message={
                            'Subject': {
                                'Data': 'Bill Summary of Account ' + json.dumps(account_ids[ai]).replace('\"','') + ' for ' + start_day_of_prev_month.strftime(('%B')) + ' ' + start_day_of_prev_month.strftime(('%Y'))
                            },
                            'Body': {
                                'Html': {
                                    'Data': bill_summary
                                }
                            }
                        }
                    )
                    
                logger.info(f"Email report of Account " + account_ids[ai] + " for the Period " + month_start_date + " to " + month_end_date)
                
            except Exception as e:
                logger.exception(e)
                pass
        
        return {
            'statusCode': 200,
            'body': json.dumps('Bill account info emailed!')
        }

    except Exception as e:
        logger.exception(e)
        raise