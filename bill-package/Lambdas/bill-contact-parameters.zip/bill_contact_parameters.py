from crhelper import CfnResource
import boto3
import os
import logging
import json

# Initialize logging
logger = logging.getLogger()
loglevel = os.environ.get('loglevel', 'INFO')
logger.setLevel(loglevel)

# Create the clients outside of the handler.
ssm = boto3.client('ssm')

HELPER = CfnResource()


@HELPER.create
@HELPER.update
def put_parameter(event, context):
    logger.info('creating/updating Parameters')

    param_names = [event['ResourceProperties']['ssm_param_prefix'] + item for item in event['ResourceProperties']['org_account_ids'].split(",")]
    param_value = event['ResourceProperties']['ses_email_addresses']

    for param_name in param_names:
        logger.info('creating/updating Parameter [' + param_name + '] with value [' + param_value + ']')
        ssm.put_parameter(
            Name=param_name,
            Description='',
            Value=param_value,
            Type='String',
            Overwrite=True
        )

@HELPER.delete
def delete(event, context):
    logger.info('Deleting Parameters')

    param_names = [event['ResourceProperties']['ssm_param_prefix'] + item for item in event['ResourceProperties']['org_account_ids'].split(",")]
    response = ssm.delete_parameters(
        Names=param_names
    )

    logger.info("Dealeted Parameteeres : " + ", ".join(response['DeletedParameters']))
    logger.info("Invalid Parameteres : " + ", ".join(response['InvalidParameters']))
def handler(event, context):
    logger.info('In Main Lambda Handler')
    logger.info(json.dumps(event))

    try:
        HELPER(event, context)

    except Exception as err:
        logger.error("send(..) failed : " + str(err))
        raise Exception(err)






